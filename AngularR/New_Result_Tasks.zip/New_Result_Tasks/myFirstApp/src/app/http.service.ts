import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class HttpService {
   constructor(private _http: HttpClient){
      this.getTasks();
      this.by("5acfdddb388ef88c04954023");
    }
    getTasks(){
    // our http response is an Observable, store it in a variable
      console.log("heloooo world")
       let tempObservable = this._http.get('/task');
    // subscribe to the Observable and provide the code we would like to do with our data from the response
       tempObservable.subscribe(data => console.log("Got our tasks!", data));
    }

    by(id){
         let temp = this._http.get('/by/'+id);

         temp.subscribe(data => console.log("Got our tasks!", data));
    }
}
